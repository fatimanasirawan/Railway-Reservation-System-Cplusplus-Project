#include <iostream>
using namespace std;

int main(){

int x,n,r,contact_num,age,city,passengers,cnic,cnic2;
string name,complaints_suggestions;
char gender;

cout<<"****************Pakistan Railway Booking System***************"<<endl<<endl;

    cout<<"1. Train Details "<<endl;
    cout<<"2. Booking Process "<<endl;
    cout<<"3. Refund Policy "<<endl;
    cout<<"4. Complaints/Suggestions"<<endl;
    cout<<"5. Exit "<<endl;
    
    cout<<"\nChoose your desired option : ";
    cin>>x;
    
if (x == 5){
      
      exit(0);
}
     if (x == 1){
    
    cout<<" --> Number of Trains = 5 "<<endl;
    cout<<" --> Free Trains = 3 "<<endl;
    cout<<" --> Timings 8 am - 12 pm "<<endl;
    cout<<" --> A train can hold upto 50 passengers"<<endl;
    cout<<" --> Fair ranges from 1500 - 2500 Rs depending upon city"<<endl;
    
    }
    else if (x == 2){
    
    cout<<"Enter Number of Passengers travelling : ";
    cin>>n;
    
    
    
    for ( int i = 1; i<=n; i++){
    
    cout<<"\nPassenger no."<<i<<" details : "<<endl<<endl;
    
    cout<<"Enter your age : ";
    cin>>age;
    
    if (age < 18){
    
    cout<<"You are not eligible to travel alone";
    exit(0);
}

    
    cout<<"Enter your name : ";
    cin>>name;
    
    cout<<"Enter your contact number : ";
    cin>>contact_num;
    
        cout<<"Enter M for Male and F for Female : ";
    cin>>gender;
    
    cout<<"Enter your CNIC : ";
    cin>>cnic;
    
    
    
    cout<<endl;
    
    cout<<"Cities Available for Booking : "<<endl;
    
cout<<"1.Rawalpindi"<<endl; 
cout<<"2.Islamabad"<<endl; 
cout<<"3.Lahore"<<endl; 
cout<<"4.Karachi"<<endl; 

cout<<"\nChoose your desired City : ";
cin>>city;

cout<<endl;

switch (city){

   case 1:

cout<<"Selected city is Rawalpindi"<<endl;
   cout<<"Fair = 1500 Rs"<<endl;
break;

case 2:

cout<<"Selected city is Islamabad"<<endl;
cout<<"Fair = 1800 Rs"<<endl;
break;

case 3:

cout<<"Selected city is Lahore"<<endl;
cout<<"Fair = 2000 Rs"<<endl;
break;

case 4:

cout<<"Selected city is Karachi"<<endl;
cout<<"Fair = 2500 Rs"<<endl;
break;



} 
       
    }
    
    cout<<"****************Confirm Details****************";
    cout<<endl;
    
    for (int i = 1; i<=n; i++){
    
    cout<<"\nPassenger no."<<i<<" details"<<endl;
    
    cout<<"Age = "<<age<<endl;
    cout<<"Name = "<<name<<endl;
    cout<<"Conatact number = "<<contact_num<<endl;
    cout<<"Gender = " <<gender<<endl;
    cout<<"City = "<<city<<endl<<endl;
    cout<<"CNIC = "<<cnic<<endl;
    
    cout<<"Press 1 to refund amount";
    cin>>r;
    
    if (r == 1){
    
    cout<<"****************Refund Policy**************** "<<endl;
    
    cout<<"Enter your CNIC for refund Policy : ";
    cin>>cnic2;
    
    if (cnic == cnic2){
    
    
    cout<<"Amount is refunded"<<endl;
    
}
else {

cout<<"Invalid Attempt!!!"<<endl;
exit(0);
}
      
    
}
      

}
    
}
     

    if (x == 3){
    
cout<<"Invalid Attempt!!!!"<<endl;
exit(0);

}


    if (x == 4){
    
cout<<"Enter Complaints/Suggestions : "<<endl;
cin>>complaints_suggestions;
exit(0);

}
    
    
    
    
}
